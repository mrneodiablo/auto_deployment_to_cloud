#!/usr/bin/env bash
/usr/bin/mysqld_safe --defaults-file=/dserver/mariadb_6380/conf/my.cnf &