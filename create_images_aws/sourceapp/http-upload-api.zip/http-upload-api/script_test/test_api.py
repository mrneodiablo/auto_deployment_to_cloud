# -*- coding: utf-8 -*-
import base64
import hashlib
import requests
import json

URL = "http://172.16.227.150:1234/api/v1/file/"

def hash_md5(data):
    md5sum = hashlib.md5()
    md5sum.update(str(data))
    return str(md5sum.hexdigest())

def generator_authen_basic():
    username = "dongvt"
    passwd   = "dongvt"
    authen_basic = base64.b64encode(username + ":" + passwd).decode("ascii")
    return str(authen_basic)

def generate_sign(md5_content_file):
    SECRET_KEY = "sdfsfFKLJodsg082343223_"
    sign = hash_md5(str(md5_content_file + SECRET_KEY))
    return sign


def upload_file(file):

    data = ""
    with open(file, 'rb') as f:
        data = f.read()
    f.close()


    files = {'files': open(file, 'rb')}
    headers = {
                'authenticate': 'Basic ' + str(generator_authen_basic()),
                'sign-client': generate_sign(hash_md5(data))
    }
    print "=========== header ============"
    print headers
    r = requests.post(URL, files=files, headers=headers)
    print "=========== respone ==========="
    print json.dumps(r.json(),indent=4)


def get_file(file_name):
    headers = {
        'authenticate': 'Basic ' + str(generator_authen_basic())
    }
    print "=========== header ============"
    print headers
    r = requests.get(URL + file_name, headers=headers)

    print "=========== respone ==========="
    print r.content


def delete_file(file_name):

    headers = {
        'authenticate': 'Basic ' + str(generator_authen_basic())
    }
    print "=========== header ============"
    print headers
    r = requests.delete(URL+ file_name, headers=headers)

    print "=========== respone ==========="
    print json.dumps(r.json(), indent=4)


if __name__ == '__main__':
    print "==== upload file sdasdas.csv"
    upload_file('datatest/case7.pdf')

    print "\n\n"
    print "==== upload file case1.txt"
    upload_file('datatest/case9.csv')


    print "\n\n"
    print "==== delete file sdasdas.csv"
    delete_file("sdasdas.csv")

    print "\n\n"
    print "==== get file case1.txt"
    get_file("case1.txt")
